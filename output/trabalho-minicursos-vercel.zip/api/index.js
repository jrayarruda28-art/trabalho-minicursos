// Handler Node.js explícito: a plataforma controla o ciclo de vida HTTP.
export { default } from '../server.js';
